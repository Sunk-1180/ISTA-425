using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// 
/// Class KillBug provides the logic for killing the Bug
/// in the space station game. It detects if the Bug is hit
/// or not, and if it is hit, then it fades the bug out of
/// the game based on fadeTime and destroys the GameObject.
/// 
/// </summary>
public class KillBug : MonoBehaviour
{

    [Tooltip("Time for Bug to fade out in seconds")]
    public float fadeTime = 0.5f;

    // Boolean for whether Bug has been hit or not
    bool isHit;

    public void setIsHit()
    {
        isHit = true;
    }

    // Start is called before the first frame update
    void Start()
    {
        isHit = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (isHit)
        {
            SpriteRenderer renderer = GetComponent<SpriteRenderer>();

            // fade the bug out of existence
            renderer.color = new Color(1.0f, 1.0f, 1.0f, (renderer.color.a - (Time.deltaTime / fadeTime)));

            if ((renderer.color.a - (Time.deltaTime / fadeTime)) < 0)
            {
                //remove the object from the game
               GameObject.Destroy(gameObject);
            }
        }
    }
}
