using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Observer : MonoBehaviour
{
    [Tooltip("Line of sight in local (object) space")]
    public Vector3 lineOfSight = Vector3.zero;
    
    GameObject gc;
    GameObject hero;

    // direction to active target (in world space)
    Vector3 targetDir  = Vector3.zero;

    // Current direction Bug is facing
    Vector3 curDir;

    // CameObject for the current torpedo bug is tracking
    GameObject curTorp = null;

    // A vector defining the surface normal in world space.
    public Vector3 getLineOfSight()
    {
        return transform.localToWorldMatrix * lineOfSight;
    }

    // Calculates and returns the dot product of two vectors
    float dotProduct(Vector3 v1, Vector3 v2)
    {
        return (v1.x * v2.x + v1.y * v2.y + v1.z * v2.z);
    }

    // Calculates and returns the cross product of two vectors
    Vector3 crossProduct(Vector3 v1, Vector3 v2)
    {
        return new Vector3((v1.y * v2.z - v1.z * v2.y), (v1.z * v2.x - v1.x * v2.z), (v1.x * v2.y - v1.y * v2.x));
    }

    // Function used to rotate the bug
    // Takes in the GameObject that the Bug is to follow
    void rotateBug(GameObject gObject)
    {
        targetDir = (gObject.transform.position - transform.position).normalized;
        float angle = (float)Math.Acos((double)dotProduct(curDir.normalized, targetDir));
        Vector3 curCP = crossProduct(curDir.normalized, targetDir);
        if (curCP.z > 0)
        {
            this.transform.Rotate(0.0f, 0.0f, angle);
        }
        else
        {
            this.transform.Rotate(0.0f, 0.0f, -angle);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        gc   = GameObject.FindGameObjectWithTag("GameController");
        hero = gc.GetComponent<GameManager> ().playerShip;
        curDir = getLineOfSight();
    }

    // Update is called once per frame
    void Update()
    {
        if (hero.GetComponent<Launcher>().GetLastTorpedo() != null)
        {
            // Follow current torpedo
            if (curTorp == null)
            {
                curTorp = hero.GetComponent<Launcher>().GetLastTorpedo();
            }
            rotateBug(curTorp);
        }
        else
        {
            // Follow Hero Ship
            rotateBug(hero);
        }
        curDir = getLineOfSight();
    }	
}
